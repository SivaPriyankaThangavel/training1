// JavaScript Document
var j;
for (var i = 0; i <= 1000000000; i += 1){
  j = i;
}
postMessage(j);
 
